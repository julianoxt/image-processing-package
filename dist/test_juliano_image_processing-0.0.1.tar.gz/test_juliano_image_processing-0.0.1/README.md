# package_name

Description. 
The package package_name is used to:
	Processing:
		- Histrogram matching
		-
	Utils
		-
		-

O pacote foi criado por Karina na plataforma DIO, dispobinilizado em:[TIEMI](https://github.com/tiemi/image-processing-package) estou replicando a informação para entender da melhor forma a utilização dos processos

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing

```bash
pip install image_processing2
```

## Usage

```python
from image_processing2.processing import combination, transformation
from image_processing2.utils import io, plot

file1_name.my_function()
```

## Author
antonio.juliano

## License
[MIT](https://choosealicense.com/licenses/mit/)